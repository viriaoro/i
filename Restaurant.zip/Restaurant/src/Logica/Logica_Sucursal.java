/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Class.Conex;
import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author ProBook
 */
public class Logica_Sucursal {
    
    
    private final String SQL_INSERT = "INSERT INTO Sucursal (Id_Sucursal, Id_Ciudad, Nombre, Direccion) values (?,?,?,?)";
    private final String SQL_SELECT = "SELECT * FROM Sucursal";
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conex CN;
    
 public Logica_Sucursal() {
    PS = null;
    CN = new Conex();
    
}
 
 
  private DefaultTableModel setTitulos() {
     DT = new DefaultTableModel();
     DT.addColumn("Id_Sucursal");
     DT.addColumn("Id_Ciudad");
     DT.addColumn("Nombre");
     DT.addColumn("Direccion");
     
     return DT;
 }
 
 
 public int insertDatos(int suc,int citi, String nom, String ubc, int res) {
     try {
         PS = (PreparedStatement) CN.getConnection().prepareStatement(SQL_INSERT);
     
         PS.setInt (1, suc);
         PS.setInt (2, citi);
         PS.setString (3, nom);
         PS.setString (4, ubc);
         res=PS.executeUpdate();
         if (res > 0){
             JOptionPane.showMessageDialog(null, "Registro Guardado");
             
         }
         
         } catch (SQLException | HeadlessException e){
             System.err.println("Error al guardar los datos en la base de datos: " + e.getMessage());
         } finally {
         PS = null;
         CN.close();
         
     }
     
     return res;
     
 }
 
 
   public void insertDatos(int suc, int citi, String nom, String ubc) {
    
    }
 
 
 
    public DefaultTableModel getDatos(){
    try {
    setTitulos();
       
    PS = CN.getConnection().prepareStatement(SQL_SELECT);
    RS = PS.executeQuery();
    Object[] fila = new Object[4];
    while (RS.next()){
        fila[0] = RS.getInt(1);
        fila[1] = RS.getInt(2);
        fila[2] = RS.getString(3);
        fila[3] = RS.getString(4);
        DT.addRow(fila);
    }
    
} catch (SQLException e){
    System.out.println("Error" + e.getMessage());

    } finally {
        PS = null;
        RS = null;
        CN.close();
    }
return DT;

}
}

    


