/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;


import Class.Conex;
import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author ProBook
 */
public class Logica_Pedido {
    
    private final String SQL_INSERT = "INSERT INTO pedido (Id_Pedido,Id_Mesero,Id_Mesa,Fecha_Pedido,Estado) values (?,?,?,?,?)";
    private final String SQL_SELECT = "SELECT * FROM Pedido";
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conex CN;
    
    
 public Logica_Pedido() {
    PS = null;
    CN = new Conex();
    
}

 private DefaultTableModel setTitulos() {
     DT = new DefaultTableModel();
     DT.addColumn("Id_Pedido");
     DT.addColumn("Id_Mesero");
     DT.addColumn("Id_Mesa");
     DT.addColumn("Fecha_Pedido");
     DT.addColumn("Estado");
     
     return DT;
 }
 
  
 
 public int insertDatos(int ped, int ms, int mes, String fech, String est) {
     int res = 0;
     try {
         
         PS = CN.getConnection().prepareStatement(SQL_INSERT);
     
         PS.setInt (1, ped);
         PS.setInt (2, ms);
         PS.setInt (3, mes);
         PS.setString (4, fech);
         PS.setString (5, est);
         res = PS.executeUpdate();
         if (res > 0){
             JOptionPane.showMessageDialog(null, "Registro Guardado");
              
         }
         
         } catch (SQLException | HeadlessException e){
             System.err.println("Error al guardar los datos en la base de datos: " + e.getMessage());
         } finally {
         PS = null;
         CN.close();
         
         
     }
     
     return res;
     
     
      
 }

    
    public DefaultTableModel getDatos(){
    try {
    setTitulos();
       
    PS = CN.getConnection().prepareStatement(SQL_SELECT);
    RS = PS.executeQuery();
    Object[] fila = new Object[5];
    while (RS.next()){
        fila[0] = RS.getInt(1);
        fila[1] = RS.getInt(2);
        fila[2] = RS.getInt(3);
        fila[3] = RS.getString(4);
        fila[4] = RS.getString(5);
        DT.addRow(fila);
    }
    
} catch (SQLException e){
    System.out.println("Error" + e.getMessage());

    } finally {
        PS = null;
        RS = null;
        CN.close();
    }
return DT;

}

    public TableModel getDato() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

    