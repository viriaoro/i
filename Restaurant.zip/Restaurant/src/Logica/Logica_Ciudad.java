    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Class.Conex;
import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
/**
 *
 * @author ProBook
 */
public class Logica_Ciudad {
    private final String SQL_INSERT = "INSERT INTO Ciudad (Id_Ciudad,Nombre) values (?,?)";
    private final String SQL_SELECT = "SELECT * FROM Ciudad";
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conex CN;
    
 public Logica_Ciudad() {
    PS = null;
    CN = new Conex();
    
}
 
 
 
  private DefaultTableModel setTitulos() {
     DT = new DefaultTableModel();
     DT.addColumn("Id_Ciudad");
     DT.addColumn("Id_Nombre");
   
     
     return DT;
 }
 
 
 public int insertDatos(int cid, String nom) {
     int res = 0;
     try {
         PS = CN.getConnection().prepareStatement(SQL_INSERT);
         PS.setInt (1, cid);
         PS.setString (2, nom);
         res=PS.executeUpdate();
         if (res > 0){
             JOptionPane.showMessageDialog(null, "Registro Guardado");
            }
         
         } catch (SQLException | HeadlessException e){
             System.err.println("Error al guardar los datos en la base de datos: " + e.getMessage());
         } finally {
         PS = null;
         CN.close();
      }
     
     return res;
     
 }
 
             
 
 
 public DefaultTableModel getDatos(){
    try {
    setTitulos();
       
    PS = CN.getConnection().prepareStatement(SQL_SELECT);
    RS = PS.executeQuery();
    Object[] fila = new Object[2];
    while (RS.next()){
        fila[0] = RS.getInt(1);
        fila[1] = RS.getString(2);
        DT.addRow(fila);
    }
    
} catch (SQLException e){
    System.out.println("Error" + e.getMessage());

    } finally {
        PS = null;
        RS = null;
        CN.close();
    }
return DT;

}

 
 
}

