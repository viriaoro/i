/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Class.Conex;
import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author ProBook
 */
public class Logica_Factura {
    
    private final String SQL_INSERT = "INSERT INTO Factura (Id_factura,Id_Cliente,Id_Sucursal,Fecha_Factura, Subtotal, Impuestos, Precio_Total, Medio_Pago) values (?,?,?,?,?,?,?,?)";
    private final String SQL_SELECT = "SELECT * FROM Factura";
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conex CN;
    
 public Logica_Factura() {
    PS = null;
    CN = new Conex();
    
}
 
 
  private DefaultTableModel setTitulos() {
     DT = new DefaultTableModel();
     DT.addColumn("Id_Factura");
     DT.addColumn("Id_Cliente");
     DT.addColumn("Id_Sucursal");
     DT.addColumn("Fecha_Factura");
     DT.addColumn("Subtotal");
     DT.addColumn("Impuestos");
     DT.addColumn("Total");
     DT.addColumn("Medio_Pago");
    
     return DT;
 }
 
 
 
 
 public int insertDatos(int fact, int cl, int scl, String fech, double sub, double imp, double pret, double medio, int res) {
     try {
         PS = (PreparedStatement) CN.getConnection().prepareStatement(SQL_INSERT);
     
         PS.setInt (1, fact);
         PS.setInt (2, cl);
         PS.setInt (3, scl);
         PS.setString (4, fech);
         PS.setDouble (5, sub);
         PS.setDouble (6, imp);
         PS.setDouble (7, pret);
         PS.setDouble (8, medio);
         res=PS.executeUpdate();
         if (res > 0){
             JOptionPane.showMessageDialog(null, "Registro Guardado");
             
         }
         
         } catch (SQLException | HeadlessException e){
             System.err.println("Error al guardar los datos en la base de datos: " + e.getMessage());
         } finally {
         PS = null;
         CN.close();
         
     }
     
     return res;
     
 }

    public void insertDatos(int fac, int cl, int suc, String dte, String sub, String imp, String prt, String mdp) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
            
    
     public DefaultTableModel getDatos(){
    try {
    setTitulos();
       
    PS = CN.getConnection().prepareStatement(SQL_SELECT);
    RS = PS.executeQuery();
    Object[] fila = new Object[8];
    while (RS.next()){
        fila[0] = RS.getInt(1);
        fila[1] = RS.getInt(2);
        fila[2] = RS.getInt(3);
        fila[3] = RS.getString(4);
        fila[4] = RS.getDouble(5);
        fila[5] = RS.getDouble(6);
        fila[6] = RS.getDouble(7);
        fila[7] = RS.getString(8); 
               
        DT.addRow(fila);
    }
    
} catch (SQLException e){
    System.out.println("Error" + e.getMessage());

    } finally {
        PS = null;
        RS = null;
        CN.close();
    }
return DT;

}
    
    
    
    
    
            }

