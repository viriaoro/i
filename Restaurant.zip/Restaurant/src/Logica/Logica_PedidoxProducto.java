/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Class.Conex;
import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author ProBook
 */
public class Logica_PedidoxProducto {
    
    
    private final String SQL_INSERT = "INSERT INTO PedidoxProducto (Id_PedidoxProducto,Id_Pedido,Id_Producto,Cantidad) values (?,?,?,?)";
    private final String SQL_SELECT = "SELECT * FROM Pedidoxproducto";
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conex CN;
    
 public Logica_PedidoxProducto() {
    PS = null;
    CN = new Conex();
    
}
 
 private DefaultTableModel setTitulos() {
     DT = new DefaultTableModel();
     DT.addColumn("Id_PedidoxProducto");
     DT.addColumn("Id_Pedido");
     DT.addColumn("Id_Producto");
     DT.addColumn("Cantidad");
     
     return DT;
 }
 
 
 
 public int insertDatos(int ped,int pedi, int pro, int cant, int res) {
     try {
         PS = (PreparedStatement) CN.getConnection().prepareStatement(SQL_INSERT);
     
         PS.setInt (1, ped);
         PS.setInt(2, pedi);
         PS.setInt (3, pro);
         PS.setInt (4, cant);
        
         res=PS.executeUpdate();
         if (res > 0){
             JOptionPane.showMessageDialog(null, "Registro Guardado");
             
         }
         
         } catch (SQLException | HeadlessException e){
             System.err.println("Error al guardar los datos en la base de datos: " + e.getMessage());
         } finally {
         PS = null;
         CN.close();
         
     }
     
     return res;
     
 }
 
  public DefaultTableModel getDatos(){
    try {
    setTitulos();
       
    PS = CN.getConnection().prepareStatement(SQL_SELECT);
    RS = PS.executeQuery();
    Object[] fila = new Object[4];
    while (RS.next()){
        fila[0] = RS.getInt(1);
        fila[1] = RS.getInt(2);
        fila[2] = RS.getInt(3);
        fila[3] = RS.getInt(4);
        DT.addRow(fila);
    }
    
} catch (SQLException e){
    System.out.println("Error" + e.getMessage());

    } finally {
        PS = null;
        RS = null;
        CN.close();
    }
return DT;

}

    public void insertDatos(int pd, int ped, int pro, int cant) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
 
 
 
            
            }

    
    
