/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Class.Conex;
import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


/**
 *
 * @author ProBook
 */
public class Logica_ProductosxFactura {
    
        
    private final String SQL_INSERT = "INSERT INTO ProductosxFactura (Id_ProductosxFactura, Id_Factura, Id_Producto, Cantidad ,Valor_Unitario) values (?,?,?,?,?)";
    private final String SQL_SELECT = "SELECT * FROM ProductosxFactura";
    private DefaultTableModel DT;
    private ResultSet RS;    
    private PreparedStatement PS;
    
    
    private final Conex CN;
    
 public Logica_ProductosxFactura() {
    PS = null;
    CN = new Conex();
    
}
 
 
  private DefaultTableModel setTitulos() {
     DT = new DefaultTableModel();
     DT.addColumn("Id_ProductosxFactura");
     DT.addColumn("Id_Factura");
     DT.addColumn("Id_Producto");
     DT.addColumn("Cantidad");
     DT.addColumn("Valor_Unitario");
     
     return DT;
 }
 
 
 
 
 
 public int insertDatos(int prodfac, int fac, int pro, int cant, Double unit, int res) {
     try {
         PS = (PreparedStatement) CN.getConnection().prepareStatement(SQL_INSERT);
     
         PS.setInt (1, prodfac);
         PS.setInt (2, fac);
         PS.setInt (3, pro);
         PS.setInt (4, cant);
         PS.setDouble (5, unit);
      
         res=PS.executeUpdate();
         if (res > 0){
             JOptionPane.showMessageDialog(null, "Registro Guardado");
             
         }
         
         } catch (SQLException | HeadlessException e){
             System.err.println("Error al guardar los datos en la base de datos: " + e.getMessage());
         } finally {
         PS = null;
         CN.close();
         
     }
     
     return res;
     
 }

    public void insertDatos(int profa, int fac, int pro, int cant, String val) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
            
 
    
    
    public DefaultTableModel getDatos(){
    try {
    setTitulos();
       
    PS = CN.getConnection().prepareStatement(SQL_SELECT);
    RS = PS.executeQuery();
    Object[] fila = new Object[5];
    while (RS.next()){
        fila[0] = RS.getInt(1);
        fila[1] = RS.getInt(2);
        fila[2] = RS.getInt(3);
        fila[3] = RS.getInt(4);
        fila[4] = RS.getDouble(5);
        DT.addRow(fila);
    }
    
} catch (SQLException e){
    System.out.println("Error" + e.getMessage());

    } finally {
        PS = null;
        RS = null;
        CN.close();
    }
return DT;

}
}

    

    

