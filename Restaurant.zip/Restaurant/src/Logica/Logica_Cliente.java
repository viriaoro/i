/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;


import Class.Conex;
import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author ProBook
 */
public class Logica_Cliente {
    
        
    private final String SQL_INSERT = "INSERT INTO Cliente (Id_Cliente,Nombre,Apellido,Celular) values (?,?,?,?)";
    private final String SQL_SELECT = "SELECT * FROM Cliente";
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conex CN;
    
 public Logica_Cliente() {
    PS = null;
    CN = new Conex();
    
}
 
 
  private DefaultTableModel setTitulos() {
     DT = new DefaultTableModel();
     DT.addColumn("Id_Cliente");
     DT.addColumn("Nombre");
     DT.addColumn("Apellido");
     DT.addColumn("Celular");
     
     return DT;
 }
 
  
 
 public int insertDatos(int cl, String nom, String app, String cel, int res) {
     try {
         PS = (PreparedStatement) CN.getConnection().prepareStatement(SQL_INSERT);
     
         PS.setInt (1, cl);
         PS.setString (2, nom);
         PS.setString (3, app);
         PS.setString (4, cel);
         res=PS.executeUpdate();
         if (res > 0){
             JOptionPane.showMessageDialog(null, "Registro Guardado");
             
         }
         
         } catch (SQLException | HeadlessException e){
             System.err.println("Error al guardar los datos en la base de datos: " + e.getMessage());
         } finally {
         PS = null;
         CN.close();
         
     }
     
     return res;
     
 }
 
 
 public void insertDatos(int cl, String nom, String app, String cel) {
        
    }
 
 
   public DefaultTableModel getDatos(){
    try {
    setTitulos();
       
    PS = CN.getConnection().prepareStatement(SQL_SELECT);
    RS = PS.executeQuery();
    Object[] fila = new Object[4];
    while (RS.next()){
        fila[0] = RS.getInt(1);
        fila[1] = RS.getString(2);
        fila[2] = RS.getString(3);
        fila[3] = RS.getString(4);
        DT.addRow(fila);
    }
    
} catch (SQLException e){
    System.out.println("Error" + e.getMessage());

    } finally {
        PS = null;
        RS = null;
        CN.close();
    }
return DT;

}

    
            
            }

    
