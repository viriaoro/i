/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Class.Conex;
import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


/**
 *
 * @author ProBook
 */
public class Logica_Producto {
    
    
    private final String SQL_INSERT = "INSERT INTO Producto (Id_Producto,Descripcion,Valor_Unitario) values (?,?,?)";
    private final String SQL_SELECT = "SELECT * FROM Producto";
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conex CN;
    
 public Logica_Producto() {
    PS = null;
    CN = new Conex();
    
}
 
 
 private DefaultTableModel setTitulos() {
     DT = new DefaultTableModel();
     DT.addColumn("Id_Producto");
     DT.addColumn("Id_Descripcion");
     DT.addColumn("Id_Valor_Unitario");
          
     return DT;
 }
 
 
 
 
 
 public int insertDatos(int pro, String desc, String valorun) {
     try {
         PS = CN.getConnection().prepareStatement(SQL_INSERT);
     
         PS.setInt (1, pro);
         PS.setString (2, desc);
         PS.setString (3,valorun);
         int res = PS.executeUpdate();
         if (res > 0){
             JOptionPane.showMessageDialog(null, "Registro Guardado");
             
         }
         
         } catch (SQLException | HeadlessException e){
             System.err.println("Error al guardar los datos en la base de datos: " + e.getMessage());
         } finally {
         PS = null;
         CN.close();
         
     }
     
     return 0;
     
 }
  
 public DefaultTableModel getDatos(){
    try {
    setTitulos();
       
    PS = CN.getConnection().prepareStatement(SQL_SELECT);
    RS = PS.executeQuery();
    Object[] fila = new Object[3];
    while (RS.next()){
        fila[0] = RS.getInt(1);
        fila[1] = RS.getString(2);
        fila[2] = RS.getDouble(3);
        DT.addRow(fila);
    }
    
} catch (SQLException e){
    System.out.println("Error" + e.getMessage());

    } finally {
        PS = null;
        RS = null;
        CN.close();
    }
return DT;

}
}

    
